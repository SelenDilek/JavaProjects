package Gun38._03_Abstract;

public class SezarSalad extends Salad{
    @Override
    String madeIn() {
        return "Mediterranean";
    }

    @Override
    String taste() {
        return super.taste();
    }
}
