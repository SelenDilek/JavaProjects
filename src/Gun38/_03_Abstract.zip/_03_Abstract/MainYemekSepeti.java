package Gun38._03_Abstract;

import Gun28._04_0rnek.Banka;

public class MainYemekSepeti {
    public static void main(String[] args) {

        System.out.println("*****YEMEK SEPETINE HOSGELDINIZ****");

        Baklava baklava = new Baklava();
        System.out.println(baklava.getClass().getSimpleName());
        System.out.println("baklava taste = " + baklava.taste());
        System.out.println("baklava = " + baklava.madeIn());

        System.out.println("________________________");

        CheeseCake cheeseCake = new CheeseCake();
        System.out.println(cheeseCake.getClass().getSimpleName());
        System.out.println("cheeseCake taste = " + cheeseCake.taste());
        System.out.println("cheeseCake madeIn = " + cheeseCake.madeIn());

        System.out.println("________________________");

        SezarSalad sezarSalad = new SezarSalad();
        System.out.println(sezarSalad.getClass().getSimpleName());
        //System.out.println("Sezar Salad taste = " + sezarSalad.taste());
        System.out.println("Sezar Salad madeIn = " + sezarSalad.madeIn());

        System.out.println("________________________");

        GreekSalad greekSalad = new GreekSalad();
        System.out.println(greekSalad.getClass().getSimpleName());
       //System.out.println("Greek Salad taste = " + greekSalad.taste());
        System.out.println("Greek Salad madeIn = " + greekSalad.madeIn());

        System.out.println();

        System.out.println("AFIYET OLSUN...");



    }
}
