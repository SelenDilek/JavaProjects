package Gun38._03_Abstract;

public class GreekSalad extends  Salad{
    @Override
    String madeIn() {
        return "Greek";
    }

    @Override
    String taste() {
        return super.taste();
    }
}
