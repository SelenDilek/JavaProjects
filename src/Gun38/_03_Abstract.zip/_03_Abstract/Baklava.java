package Gun38._03_Abstract;

public class Baklava extends Sweet{
    @Override
    String madeIn() {
        return "Turkey";
    }

    @Override
    String taste() {
        return super.taste();
    }
}
