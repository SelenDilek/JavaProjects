package Gun38._03_Abstract;

public abstract class Food {

    abstract String madeIn();
    abstract String taste();


}
