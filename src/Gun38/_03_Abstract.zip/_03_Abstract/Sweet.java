package Gun38._03_Abstract;

public abstract class Sweet extends Food {
    @Override
    String madeIn() {
        return null;
    }

    @Override
    String taste() {
        return "good , sugar , sweet";
    }
}
