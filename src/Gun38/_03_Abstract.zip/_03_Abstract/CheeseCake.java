package Gun38._03_Abstract;

public class CheeseCake extends  Sweet{
    @Override
    String madeIn() {
        return "US";
    }

    @Override
    String taste() {
        return super.taste();
    }
}
