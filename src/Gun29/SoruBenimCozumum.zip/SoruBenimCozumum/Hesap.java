package Gun29.SoruBenimCozumum;

public class Hesap {
    int yatan=0 ;
    int cekilen=0 ;
    private int bakiye=500 ;
    int bakiyeSonDurum=0;


    public void Yatirma(int yatirilan){


         bakiyeSonDurum= bakiye+yatirilan;

         yatan=yatan+yatirilan;


    }

    public void Cektirme(int cekme){


      bakiyeSonDurum= bakiyeSonDurum- cekme ;
      cekilen=cekilen+cekme;


    }


    @Override
    public String toString() {
        return "Hesap{" +
                "yatan=" + yatan +
                ", cekilen=" + cekilen +
                ", bakiye=" + bakiye +
                '}';
    }
}
